ProgressCircle
==============

圆圈形进度条，[示例参看]()

最近有需求，使用Flex SDK3.5做了一个圆圈进度条，画扇型是参考http://ntt.cc/2008/09/22/tutorials-step-by-step-to-create-your-sector-menu.html做的